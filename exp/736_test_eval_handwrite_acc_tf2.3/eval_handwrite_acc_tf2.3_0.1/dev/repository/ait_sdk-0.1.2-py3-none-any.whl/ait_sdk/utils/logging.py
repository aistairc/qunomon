# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8
import inspect
import logging
from functools import wraps
from pathlib import Path


class CustomFilter(logging.Filter):
    """logger用のユーザー定義フィルター"""

    def filter(self, record) -> bool:
        """呼び出し元のファイル名、関数名、行番号が表示されるようにする関数
        これでフィルタリングしないとデコレーターを使用した関数(呼び出し元)に関する情報ではなく、
        test1.pyの後述のlog関数を元にした情報が出力される

        Returns:
            True: 常にフィルターをパスする
        """

        record.real_filename = getattr(record,
                                       'real_filename',
                                       record.filename)
        record.real_funcName = getattr(record,
                                       'real_funcName',
                                       record.funcName)
        record.real_lineno = getattr(record,
                                     'real_lineno',
                                     record.lineno)
        return True


# グローバル変数 ログ保存フォルダパス
g_log_dir = Path('./')


def set_log_dir(dir: str) -> None:
    global g_log_dir
    g_log_dir = Path(dir)


def get_log_path() -> str:
    return str(g_log_dir / 'ait.log')


def get_logger() -> logging.Logger:
    """logging.Loggerの作成

    Returns:
        logger (logging.Logger): logging.Loggerのインスタンス
    """

    # basicConfigのformat引数でログのフォーマットを指定する 
    log_format = '[%(asctime)s] [%(thread)d] %(levelname)s\t%(real_filename)s' \
                 ' - %(real_funcName)s:%(real_lineno)s -> %(message)s'
    logging.basicConfig(filename=get_log_path(), 
                        format=log_format, 
                        level=logging.DEBUG,
                        filemode='w')
    logger = logging.getLogger(__name__)
    logger.addFilter(CustomFilter())
    return logger


def log(logger):
    """デコレーターでloggerを引数にとるためのラッパー関数

    Args:
        logger (logging.Logger)

    Returns:
        _decoratorの返り値
    """

    def _decorator(func):
        """デコレーターを使用する関数を引数とする

        Args:
            func (function)

        Returns:
            wrapperの返り値
        """

        # funcのメタデータを引き継ぐ
        @wraps(func)
        def wrapper(*args, **kwargs):
            """実際の処理を書くための関数

            Args:
                *args, **kwargs: funcの引数

            Returns:
                funcの返り値
            """

            func_name = func.__name__
            # loggerで使用するためにfuncに関する情報をdict化
            extra = {
                'real_filename': inspect.getfile(func),
                'real_funcName': func_name,
                'real_lineno': inspect.currentframe().f_back.f_lineno
            }

            if (args is not None) and (len(args) != 0):
                args_str = ','.join([str(a) for a in args])
                message = f'[START] {func_name}({args_str})'
            else:
                message = f'[START] {func_name}()'
            logger.debug(message, extra=extra)

            try:
                # funcの実行
                ret = func(*args, **kwargs)
                if ret is not None:
                    logger.debug(f'[END] {func_name}() = {ret}', extra=extra)
                else:
                    logger.debug(f'[END] {func_name}()', extra=extra)
                return ret
            except Exception as err:
                # funcのエラーハンドリング
                logger.error(err, exc_info=True, extra=extra)
                logger.error(f'[KILLED] {func_name}()', extra=extra)
                raise

        return wrapper
    return _decorator
