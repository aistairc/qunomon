# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8
import gzip
import numpy as np


class MNIST:

    def load_image(self, file_path: str, image_size: int) -> np.ndarray:
        with gzip.open(file_path, 'rb') as f:
            data = np.frombuffer(f.read(), np.uint8, offset=16)
        data = data.reshape(-1, image_size, image_size)
        return data

    def load_label(self, file_path: str) -> np.ndarray:
        with gzip.open(file_path, 'rb') as f:
            labels = np.frombuffer(f.read(), np.uint8, offset=8)
        return labels
