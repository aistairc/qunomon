import sys
from pathlib import Path
import json
import shutil
import os
import glob

print('hello test-runner')

# check args
index: int = 0
for x in sys.argv:
    print('args[{}]:{}'.format(str(index), x))
    index += 1

if len(sys.argv) != 1:
    args_file = Path().cwd() / 'mnt' / 'ip' / 'job_args' / sys.argv[1] / 'args.json'
else:
    # args_file
    args_file = Path().cwd() / 'args' / 'args.json'
print('args_file:{}'.format(str(args_file)))

# 初期値設定
summary_json_path = Path().cwd() / 'mnt' / 'ip' / 'job_result' / sys.argv[1] / 'summary.json'

try:
    # read args_file
    print('{} - args_file:{}'.format(str(args_file.exists()), str(args_file)))
    with open(str(args_file)) as f:
        args_json = json.load(f)

    # mount_dir
    mount_dir = str([m['dst_path'] for m in args_json['mounts'] if m['name'] == 'mount_dir'][0])
    print('mount_dir:{}'.format(mount_dir))
    files = os.listdir(Path(mount_dir))
    print(files)

    # inventory
    inventory_dir = Path(mount_dir + '/ip/job_args/' + sys.argv[1])
    # inventory_dir = Path([m['dst_path'] for m in args_json['mounts'] if m['name'] == 'args_dir'][0])
    print('inventory_dir:{}'.format(str(inventory_dir)))

    # result
    result_dir = Path(mount_dir + '/ip/job_result/' + sys.argv[1])
    # result_dir = Path([m['dst_path'] for m in args_json['mounts'] if m['name'] == 'result_dir'][0])
    print('result_dir:{}'.format(str(result_dir)))

    for arg in args_json['method_params']:
        print('name:{}'.format(arg['name']))
        print('value:{}'.format(arg['value']))
    for arg in args_json['condition_params']:
        print('name:{}'.format(arg['name']))
        print('value:{}'.format(arg['value']))
    for arg in args_json['inventories']:
        print('name:{}'.format(arg['name']))
        print('value:{}'.format(arg['value']))

    print('read inventory')

    # read inventory
    for arg in args_json['inventories']:
        name = arg['name']
        value = arg['value']
        with open(value) as f:
            print(f.read())

    print('main process')
    # 本処理：ここではダミーデータのコピーと結果出力 
    src_dir = Path().cwd() / 'dummy_result_data'
    print('src_dir:{}'.format(src_dir))
    files = os.listdir(Path(src_dir))
    print(files)
    print('{} - src_dir:{}'.format(str(src_dir.exists()), str(src_dir)))
    print('{} - result_dir:{}'.format(str(result_dir.exists()), str(result_dir)))

    if src_dir.exists():
        os.makedirs(Path(result_dir), exist_ok=True)
        for src_file in src_dir.glob("*"):
            shutil.copy(src=str(src_file), dst=str(result_dir/src_file.name))

    # write result
    summary_json = {"result": "OK"}
    with open(str(summary_json_path), 'w') as f:
        json.dump(summary_json, f, indent=4)

    for path in Path().cwd().glob("*/*"):
        print('{}'.format(str(path)))

except Exception as e:
    print('Exception: {}'.format(e))
    try:
        summary_json = {"result": "ERR"}
        summary_json['detail'] = str(e)
        with open(str(summary_json_path), 'w') as f:
            json.dump(summary_json, f, indent=4)
    except:
        print('Failed write summary_json:{}'.format(str(summary_json_path)))
    raise e
