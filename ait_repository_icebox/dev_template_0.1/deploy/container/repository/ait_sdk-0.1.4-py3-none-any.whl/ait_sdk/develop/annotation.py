# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8
from functools import wraps

from ..utils.timer import Timer
from ..common.files.ait_output import AITOutput
from .ait_path_helper import AITPathHelper


def ait_main(ait_output: AITOutput, path_helper: AITPathHelper):
    """mainラッパー関数
    main関数の実行時間計測、およびait_outputの出力を実施する。

    Args:
        ait_output (ait_sdl.common.files.ait_output.AITOutput)
        path_helper (ait_sdl.develop.ait_path_helper.AITPathHelper)

    Returns:
        _decoratorの返り値
    """

    def _decorator(func):
        """デコレーターを使用する関数を引数とする

        Args:
            func (function)

        Returns:
            wrapperの返り値
        """

        # funcのメタデータを引き継ぐ
        @wraps(func)
        def wrapper(*args, **kwargs):
            """実際の処理を書くための関数

            Args:
                *args, **kwargs: funcの引数

            Returns:
                funcの返り値
            """

            timer = Timer()
            timer.start_timer()

            # funcの実行
            ret = func(*args, **kwargs)

            timer.stop_timer()
            ait_output.write_output(output_file_path=path_helper.get_output_file_path(),
                                    start_dt=timer.get_start_dt(),
                                    stop_dt=timer.get_stop_dt())

            return ret
        return wrapper
    return _decorator


def measures(ait_output: AITOutput, *names: str, is_many: bool = False):
    """measureを追加するためのラッパー関数

    Args:
        ait_output (ait_sdl.common.files.ait_output.AITOutput)
        names (str)
        is_many (bool)

    Returns:
        _decoratorの返り値
    """

    def _decorator(func):
        """デコレーターを使用する関数を引数とする

        Args:
            func (function)

        Returns:
            wrapperの返り値
        """

        # funcのメタデータを引き継ぐ
        @wraps(func)
        def wrapper(*args, **kwargs):
            """実際の処理を書くための関数

            Args:
                *args, **kwargs: funcの引数

            Returns:
                funcの返り値
            """

            # funcの実行
            ret = func(*args, **kwargs)

            # measure追加
            if type(ret) is not tuple:
                if not is_many:
                    ait_output.add_measure(name=names[0], value=str(ret))
                else:
                    ait_output.add_measure(name=names[0], value=','.join(map(str, ret)))
            else:
                for val, name in zip(ret, names):
                    if not is_many:
                        ait_output.add_measure(name=name, value=str(val))
                    else:
                        ait_output.add_measure(name=name, value=','.join(map(str, val)))

            return ret
        return wrapper
    return _decorator


def resources(ait_output: AITOutput, path_helper: AITPathHelper, name: str):
    """resourceを追加するためのラッパー関数

    デコレータで読み込んだfile_pathを設定するため、関数の引数にはかならずfile_pathを定義すること。
    ひとつのresourceに複数ファイルを設定する場合は、list型かtuple型でパスを返却すること。

    Args:
        ait_output (ait_sdl.common.files.ait_output.AITOutput)
        path_helper (ait_sdl.develop.ait_path_helper.AITPathHelper)
        name (str)

    Returns:
        _decoratorの返り値
    """

    def _decorator(func):
        """デコレーターを使用する関数を引数とする

        Args:
            func (function)

        Returns:
            wrapperの返り値
        """

        # funcのメタデータを引き継ぐ
        @wraps(func)
        def wrapper(*args, **kwargs):
            """実際の処理を書くための関数

            Args:
                *args, **kwargs: funcの引数

            Returns:
                funcの返り値
            """

            file_path = path_helper.get_output_resource_path(name)
            kwargs['file_path'] = file_path

            # funcの実行
            ret = func(*args, **kwargs)

            # resource追加
            if type(ret) is list or type(ret) is tuple:
                for val in ret:
                    ait_output.add_resource(name=name, path=val)
            else:
                ait_output.add_resource(name=name, path=file_path)

            return ret
        return wrapper
    return _decorator


def downloads(ait_output: AITOutput, path_helper: AITPathHelper, name: str):
    """downloadを追加するためのラッパー関数

    デコレータで読み込んだfile_pathを設定するため、関数の引数にはかならずfile_pathを定義すること。
    ひとつのdownloadに複数ファイルを設定する場合は、list型かtuple型でパスを返却すること。

    Args:
        ait_output (ait_sdl.common.files.ait_output.AITOutput)
        path_helper (ait_sdl.develop.ait_path_helper.AITPathHelper)
        name (str)

    Returns:
        _decoratorの返り値
    """

    def _decorator(func):
        """デコレーターを使用する関数を引数とする

        Args:
            func (function)

        Returns:
            wrapperの返り値
        """

        # funcのメタデータを引き継ぐ
        @wraps(func)
        def wrapper(*args, **kwargs):
            """実際の処理を書くための関数

            Args:
                *args, **kwargs: funcの引数

            Returns:
                funcの返り値
            """

            file_path = path_helper.get_output_download_path(name)
            kwargs['file_path'] = file_path

            # funcの実行
            ret = func(*args, **kwargs)

            # resource追加
            if type(ret) is list or type(ret) is tuple:
                for val in ret:
                    ait_output.add_downloads(name=name, path=val)
            else:
                ait_output.add_downloads(name=name, path=file_path)

            return ret
        return wrapper
    return _decorator
