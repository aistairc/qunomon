# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8
from typing import List, Dict, Optional
import json

from ...utils.logging import log, get_logger


logger = get_logger()


class AITManifestGenerator():
    """ait.manifest.jsonを出力するためのクラス。
    set関数で各項目を入力し、write関数でjsonを出力する。
    """
    def __init__(self):
        """コンストラクタ
        """
        self._ait_name = ""
        self._ait_description = ""
        self._ait_author = ""
        self._ait_email = ""
        self._ait_version = ""
        self._ait_quality = ""
        self._ait_reference = ""
 
        self._ait_inventories = []
        self._ait_parameters = []
        self._ait_measures = []
        self._ait_resources = []
        self._ait_downloads = []

    @log(logger)
    def set_ait_name(self, name: str) -> None:
        """name項目を設定する。

        Args:
            name (str)

        Returns:
            無し
        """
        self._ait_name = name

    @log(logger)
    def set_ait_description(self, description: str) -> None:
        """description項目を設定する。

        Args:
            description (str)

        Returns:
            無し
        """
        self._ait_description = description

    @log(logger)
    def set_ait_author(self, author: str) -> None:
        """author項目を設定する。

        Args:
            author (str)

        Returns:
            無し
        """
        self._ait_author = author

    @log(logger)
    def set_ait_email(self, email: str) -> None:
        """email項目を設定する。

        Args:
            email (str)

        Returns:
            無し
        """
        self._ait_email = email

    @log(logger)
    def set_ait_version(self, version: str) -> None:
        """version項目を設定する。

        Args:
            version (str)

        Returns:
            無し
        """
        self._ait_version = version

    @log(logger)
    def set_ait_quality(self, quality: str) -> None:
        """quality項目を設定する。

        Args:
            quality (str)

        Returns:
            無し
        """
        self._ait_quality = quality

    @log(logger)
    def set_ait_reference(self, reference: str) -> None:
        """reference項目を設定する。

        Args:
            reference (str)

        Returns:
            無し
        """
        self._ait_reference = reference

    # inventories
    @log(logger)
    def add_ait_inventories(self, name: str, type: str, description: str, format: list, schema: str='')-> None:
        """inventories項目を設定する。

        Args:
            name (str)
            type (str)
            description (str)
            format (List)
            schema (str) ：任意

        Returns:
            無し
        """
        self._ait_inventories.append({'name': name, 'type': type, 'description': description, 'format': format, 'schema': schema})

    # parameters
    @log(logger)
    def add_ait_parameters(self, name: str, type: str, description: str, default_val: str='')-> None:
        """parameters項目を設定する。

        Args:
            name (str)
            type (str)
            description (str)
            default_val (str) ：任意

        Returns:
            無し
        """
        self._ait_parameters.append({'name': name, 'type': type, 'description': description, 'default_val': default_val})

    # measures
    @log(logger)
    def add_ait_measures(self, name: str, type: str, description: str, structure: str)-> None:
        """measures項目を設定する。

        Args:
            name (str)
            type (str)
            description (str)
            structure (str) 

        Returns:
            無し
        """
        self._ait_measures.append({'name': name, 'type': type, 'description': description, 'structure': structure})

    # resources
    @log(logger)
    def add_ait_resources(self, name: str, path: str, type: str, description: str) -> None:
        """resources項目を設定する。

        Args:
            name (str)
            path (str) 
            type (str)
            description (str)

        Returns:
            無し
        """
        self._ait_resources.append({'name': name, 'path': path, 'type': type, 'description': description})

    # downloads
    @log(logger)
    def add_ait_downloads(self, name: str, path: str, description: str)-> None:
        """downloads項目を設定する。

        Args:
            name (str)
            path (str) 
            description (str)

        Returns:
            無し
        """
        self._ait_downloads.append({'name': name, 'path': path, 'description': description})

    @log(logger)
    def write(self, output_file_path: str) -> None:
        """設定した各項目をjsonファイルに出力する。

        Args:
            output_file_path (str)

        Returns:
            無し
        """
        output_json = {
            'name': self._ait_name,
            'description': self._ait_description,
            'author': self._ait_author,
            'email': self._ait_email,
            'version': self._ait_version,
            'quality': self._ait_quality,
            'reference': self._ait_reference
            }
        
        output_json['inventories'] = self._ait_inventories
        output_json['parameters'] = self._ait_parameters
        output_json['report'] = {}
        output_json['report']['measures'] = self._ait_measures
        output_json['report']['resources'] = self._ait_resources
        output_json['downloads'] = self._ait_downloads

        with open(output_file_path, 'w', encoding='utf-8') as f:
            json.dump(output_json, f, indent=4, ensure_ascii=False)


