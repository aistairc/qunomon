# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8
from typing import List, Dict, Optional
import json

from ...utils.logging import log, get_logger


logger = get_logger()


class AITManifest():

    def __init__(self):
        self._manifest_json = None

    @log(logger)
    def read_json(self, manifest_json_path: str) -> None:
        # read manifest file
        with open(manifest_json_path, encoding='utf-8') as f:
            self._manifest_json = json.load(f)

    @log(logger)
    def get_ait_measures(self) -> List[Dict[str, str]]:
        return self._manifest_json['report']['measures']

    @log(logger)
    def get_ait_resources(self) -> List[Dict[str, str]]:
        return self._manifest_json['report']['resources']

    @log(logger)
    def get_ait_downloads(self) -> List[Dict[str, str]]:
        return self._manifest_json['downloads']

    @log(logger)
    def get_name(self) -> str:
        return self._manifest_json['name']

    @log(logger)
    def get_version(self) -> str:
        return self._manifest_json['version']

    @log(logger)
    def get_ait_resource_path(self, name: str) -> str:
        return self._find_path(section=self._manifest_json['report']['resources'],
                               value_key='path',
                               name=name)
        
    @log(logger)
    def get_ait_download_path(self, name: str, is_raise_key_error: bool = True) -> str:
        return self._find_path(section=self._manifest_json['downloads'],
                               value_key='path',
                               name=name,
                               is_raise_key_error=is_raise_key_error)

    @log(logger)
    def get_ait_parameter_default_value(self, name: str, is_raise_key_error: bool = True) -> str:
        return self._find_path(section=self._manifest_json['parameters'],
                               value_key='default_val',
                               name=name,
                               is_raise_key_error=is_raise_key_error)

    @log(logger)
    def get_ait_parameter_type(self, name: str) -> str:
        return self._find_path(section=self._manifest_json['parameters'],
                               value_key='type',
                               name=name)

    @log(logger)
    def _find_path(self, section: List[Dict[str, str]], value_key: str, name: str,
                   is_raise_key_error: bool = True) -> Optional[str]:
        paths = [i[value_key] for i in section if i['name'] == name]
        if len(paths) == 0:
            if is_raise_key_error:
                raise KeyError(f'{name} is not found.')
            else:
                return None
        return paths[0]
