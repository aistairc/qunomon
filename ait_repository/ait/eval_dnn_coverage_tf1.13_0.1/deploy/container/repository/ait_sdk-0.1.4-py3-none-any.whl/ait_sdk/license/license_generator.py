# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8
from . import license_setting


class LicenseGenerator:
    """LICENSE.txtを出力するためのクラス。
    """
    def __init__(self):
        """コンストラクタ
        """

    def write(self, licence_path: str, year: str, owner: str) -> None:
        """LICENSE.txtを出力する。

        Args:
            licence_path (str) : ライセンスファイルのパス
            year (str) : 著作物発行年。
            owner (str) : 著作権者名。
        Returns:
            無し
        """
        with open(licence_path, 'w', encoding='utf-8') as f:
            f.write(license_setting.license_template.format(year, owner))
