# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8
from datetime import datetime, timezone, timedelta


class Timer:

    def __init__(self):
        self._start_dt = None
        self._stop_dt = None

    def start_timer(self) -> None:
        self._start_dt = datetime.now(timezone(timedelta(hours=9)))
        self._stop_dt = None

    def stop_timer(self) -> None:
        self._stop_dt = datetime.now(timezone(timedelta(hours=9)))

    def get_start_dt(self) -> datetime:
        return self._start_dt

    def get_stop_dt(self) -> datetime:
        return self._stop_dt
