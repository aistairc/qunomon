# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8
from typing import List
from pathlib import Path

from ..common.files.ait_input import AITInput
from ..common.files.ait_manifest import AITManifest
from ..utils.exception import InvalidOperationException
from ..utils.logging import log, get_logger


logger = get_logger()


class AITPathHelper:

    @log(logger)
    def __init__(self, argv: List[str], ait_input: AITInput, ait_manifest: AITManifest, entry_point_dir: str):
        # check args
        if len(argv) != 2:
            raise InvalidOperationException('Invalid Argument.')

        self._args_dir = argv[1]
        self._ait_input = ait_input
        self._ait_manifest = ait_manifest
        self._entry_point_dir = entry_point_dir

    @log(logger)
    def get_manifest_file_path(self) -> str:
        return str(Path(self._entry_point_dir) / 'ait.manifest.json')

    @log(logger)
    def get_input_file_path(self) -> str:
        return str(Path(self._args_dir) / 'ait.input.json')

    @log(logger)
    def get_output_file_path(self) -> str:
        return str(self._get_result_dir_path() / 'ait.output.json')

    @log(logger)
    def _get_result_dir_path(self) -> Path:
        return self._ait_input.get_mount_dir_path() / 'ip' / 'job_result' / \
               str(self._ait_input.get_job_id()) / \
               str(self._ait_input.get_run_id())

    @log(logger)
    def get_output_resource_path(self, item_name: str) -> str:
        org_path = self._ait_manifest.get_ait_resource_path(item_name)
        return org_path.replace('/usr/local/qai', str(self._get_result_dir_path()))

    @log(logger)
    def get_output_download_path(self, item_name: str, is_raise_key_error: bool = True) -> str:
        org_path = self._ait_manifest.get_ait_download_path(item_name, is_raise_key_error)
        return org_path.replace('/usr/local/qai', str(self._get_result_dir_path()))
