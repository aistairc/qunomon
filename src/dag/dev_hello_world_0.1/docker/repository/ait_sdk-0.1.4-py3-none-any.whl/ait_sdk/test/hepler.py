# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8
import requests
from pathlib import Path
import zipfile
from glob import glob
import pprint
import json
import time
from os import remove


class Helper:

    def __init__(self, backend_entry_point: str, ip_entry_point: str,
                 ait_dir: Path = None, ait_full_name: str = None, org_name: str = 'dep-a', ml_component_id: str = 1):
        self._backend_entry_point = backend_entry_point
        self._ip_entry_point = ip_entry_point
        self._org_name = org_name
        self._ml_component_id = ml_component_id
        self._ait_dir = ait_dir
        self._ait_full_name = ait_full_name
        self._internal_dir = 'container'

        self._wait_animation = [
            " [*     ]",
            " [ *    ]",
            " [  *   ]",
            " [   *  ]",
            " [    * ]",
            " [     *]",
            " [    * ]",
            " [   *  ]",
            " [  *   ]",
            " [ *    ]",
        ]

    def get_bk(self, path: str, is_print_response: bool = True, is_print_json: bool = True):
        response = requests.get(f'{self._backend_entry_point}{path}')
        if is_print_response:
            print(response)
        if is_print_json:
            pprint.pprint(response.json())
        return response

    def get_ip(self, path: str, is_print_response: bool = True, is_print_json: bool = True):
        response = requests.get(f'{self._ip_entry_point}{path}')
        if is_print_response:
            print(response)
        if is_print_json:
            pprint.pprint(response.json())
        return response

    def post_bk(self, path: str, data, is_print_response: bool = True, is_print_json: bool = True):
        response = requests.post(f'{self._backend_entry_point}{path}',
                                 json.dumps(data),
                                 headers={'Content-Type': 'application/json'})
        if is_print_response:
            print(response)
        if is_print_json:
            pprint.pprint(response.json())
        return response

    def post_ip(self, path: str, data, is_print_response: bool = True, is_print_json: bool = True):
        response = requests.post(f'{self._ip_entry_point}{path}',
                                 json.dumps(data),
                                 headers={'Content-Type': 'application/json'})
        if is_print_response:
            print(response)
        if is_print_json:
            pprint.pprint(response.json())
        return response

    def upload_zip_id(self, zip_path: str):
        file_obj = open(zip_path, 'rb')
        response = requests.post(f'{self._ip_entry_point}/deploy-dag',
                                 data={"name": "dag_zip"},
                                 files={"archive": (str(Path(zip_path).name), file_obj)})
        print(response)
        pprint.pprint(response.json())
        return response

    def _create_zip(self, ait_dir=None, ait_full_name=None):
        zip_dir = ait_dir / 'deploy'
        zip_file = Path(__file__).parent / f'{ait_full_name}.zip'

        with zipfile.ZipFile(zip_file, 'w', compression=zipfile.ZIP_STORED) as new_zip:
            new_zip.write(str(zip_dir.joinpath('dag.py')), arcname=f'{ait_full_name}/dag.py')
            new_zip.write(str(zip_dir.joinpath(self._internal_dir).joinpath('dockerfile')),
                          arcname=f'{ait_full_name}/{self._internal_dir}/dockerfile')

            dir_path = zip_dir.joinpath(self._internal_dir).joinpath('repository')
            files = glob(str(dir_path.joinpath('**')), recursive=True)
            for file in files:
                file_name = Path(file).name
                new_zip.write(file, arcname=f'{ait_full_name}/{self._internal_dir}/repository/{file_name}')
        return zip_file

    def async_build_ait(self, zip_path):
        zip_name = str(Path(zip_path).name)
        with open(zip_path, 'rb') as file_obj:
            response = requests.post(f'{self._ip_entry_point}/async-deploy-dag',
                                     files={"dag_zip": (zip_name, file_obj)})
        print(response)
        pprint.pprint(response.json())
        return response

    def post_manifest(self, manifest_path):
        manifest_name = str(Path(manifest_path).name)
        with open(manifest_path, 'rb') as file_obj:
            response = requests.post(f'{self._backend_entry_point}/testRunners/manifest',
                                     files={"ait.manifest": (manifest_name, file_obj)})
        print(response)
        pprint.pprint(response.json())
        return response

    @staticmethod
    def _find_file(dir_path: Path, file_name: str):
        files = glob(str(dir_path.joinpath(f'**/{file_name}')), recursive=True)
        if len(files) == 0:
            raise Exception(f'not found {file_name} in zip.')
        elif len(files) > 1:
            raise Exception(f'{file_name} must be one exists in zip.')
        return files[0]

    def deploy_ait_async_and_wait(self, ait_dir=None, ait_full_name=None, need_build_container: bool = True,
                                  wait_time=0.5):

        if ait_dir is None:
            ait_dir = self._ait_dir

        if ait_full_name is None:
            ait_full_name = self._ait_full_name

        self._deploy_ait_async(ait_dir, ait_full_name, need_build_container=need_build_container)
        self._wait_deploy_complete(wait_time=wait_time)

    def deploy_ait_non_build(self, ait_dir=None, ait_full_name=None):

        if ait_dir is None:
            ait_dir = self._ait_dir

        if ait_full_name is None:
            ait_full_name = self._ait_full_name

        # add manifest
        self.post_manifest(self._find_file(ait_dir / 'deploy' / self._internal_dir, 'ait.manifest.json'))

        # deploy
        zip_path = self._create_zip(ait_dir, ait_full_name)
        zip_name = str(Path(zip_path).name)
        with open(zip_path, 'rb') as file_obj:
            response = requests.post(f'{self._ip_entry_point}/deploy-dag-non-build',
                                     files={"dag_zip": (zip_name, file_obj)})
        print(response)
        pprint.pprint(response.json())
        remove(zip_path)

    def _deploy_ait_async(self, ait_dir=None, ait_full_name=None, need_build_container: bool = True):
        # add manifest
        self.post_manifest(self._find_file(ait_dir / 'deploy' / self._internal_dir, 'ait.manifest.json'))

        # deploy
        if need_build_container:
            zip_file = self._create_zip(ait_dir, ait_full_name)
            self.async_build_ait(zip_file)
            remove(zip_file)

    def _wait_deploy_complete(self, wait_time: float = 1):
        i = 0

        while True:
            print(self._wait_animation[i % len(self._wait_animation)], end="\r")
            i += 1

            json_ = self.get_ip('/async-deploy-dag', is_print_response=False, is_print_json=False).json()
            if json_['Code'] != 'D00011':
                if json_['Code'] != 'D00010':
                    # D00010以外はエラー発生のため、コンソールに出力
                    pprint.pprint(json_)
                else:
                    print('complete')
                break
            time.sleep(wait_time)

    def _wait_run_complete(self, wait_time: float = 1):
        i = 0

        while True:
            print(self._wait_animation[i % len(self._wait_animation)], end="\r")
            i += 1

            run_status = self.get_bk(f'/{self._org_name}/mlComponents/{self._ml_component_id}/testDescriotions/run-status',
                                     is_print_response=False,
                                     is_print_json=False).json()
            if run_status['Job']['Status'] != 'RUNNING':
                pprint.pprint(run_status['Runs'])
                break
            time.sleep(wait_time)

    def post_inventory(self, name: str, type_id: int, file_system_id: int, file_pass: str, description: str,
                       formats: []) -> str:
        inventory_name = f'{self._ait_full_name}_{name}'
        self.post_bk(f'/{self._org_name}/mlComponents/{self._ml_component_id}/inventories', {
            'Name': inventory_name,
            'TypeId': type_id,
            'FileSystemId': file_system_id,
            'FilePath': file_pass,
            'Description': description,
            'Formats': formats,
        })
        return inventory_name

    def get_inventory(self, name: str):
        res_json = self.get_bk(f'/{self._org_name}/mlComponents/{self._ml_component_id}/inventories',
                               is_print_json=False).json()
        return [j for j in res_json['Inventories'] if j['Name'] == name][-1]

    def post_td(self, name: str, quality_dimension_id: id, quality_measurements, target_inventories, test_runner):
        self.post_bk(f'/{self._org_name}/mlComponents/{self._ml_component_id}/testDescriotions', {
            'Name': name,
            'QualityDimensionID': quality_dimension_id,
            'QualityMeasurements': quality_measurements,
            'TargetInventories': target_inventories,
            'TestRunner': test_runner
        })

    def get_td(self, name: str):
        res_json = self.get_bk(f'/{self._org_name}/mlComponents/{self._ml_component_id}/testDescriotions',
                               is_print_json=False).json()
        return [j for j in res_json['Test']['TestDescriptions'] if j['Name'] == name][-1]

    def post_run_and_wait(self, *td_id):
        wait_time = 0.5
        self.post_bk(f'/{self._org_name}/mlComponents/{self._ml_component_id}/testDescriotions/runners', {
            "Command": "AsyncStart",
            "TestDescriptionIds": list(td_id)
        })

        self._wait_run_complete(wait_time=wait_time)

    def get_td_detail(self, td_id: int):
        return self.get_bk(f'/{self._org_name}/mlComponents/{self._ml_component_id}/testDescriotions/{td_id}',
                           is_print_json=False).json()

    def post_report(self, *td_id):
        return self.post_bk(f'/{self._org_name}/mlComponents/{self._ml_component_id}/testDescriotions/reportGenerator', {
            "Command": "Generate",
            "Destination": [str(t) for t in td_id]
        }).json()

    def post_ml_component(self, name: str, description: str, problem_domain: str, ml_framework_id: int = -1):
        if ml_framework_id == -1:
            ml_framework_id = self.get_bk('/mlFrameworks',
                                          is_print_response=False,
                                          is_print_json=False).json()['MLFrameworks'][0]['Id']

        return self.post_bk(f'/{self._org_name}/mlComponents', {
            'Name': name,
            'Description': description,
            'ProblemDomain': problem_domain,
            'MLFrameworkId': ml_framework_id
        }).json()

    def set_ml_component_id(self, ml_component_id: int):
        self._ml_component_id = ml_component_id

    def get_data_types(self):
        res_json = self.get_bk('/dataTypes',
                               is_print_response=False,
                               is_print_json=False).json()
        return res_json

    def get_file_systems(self):
        res_json = self.get_bk('/fileSystems',
                               is_print_response=False,
                               is_print_json=False).json()
        return res_json
