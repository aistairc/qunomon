# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8

import shutil
import os
from pathlib import Path

from ...utils.logging import log, get_logger


logger = get_logger()


class AITRequirementsGenerator():
    """requirements.txtを出力するためのクラス。
    """
    def __init__(self):
        """コンストラクタ
        """
        self._req_name = 'requirements.txt'
        self._package_list = []

    @log(logger)
    def add_package(self, package_name: str, package_ver: str='') -> None:
        """パッケージ情報のリストを作成する。

        Args:
            package_name (str) : インストールするパッケージ名
            package_ver (str) : インストールするパッケージのバージョン（任意）

        Returns:
            無し
        """
        if (package_ver is not None) and (len(package_ver) > 0):
            # バージョン情報あり
            self._package_list.append(package_name + '==' + package_ver)
        else:
            # バージョン情報なし
            self._package_list.append(package_name)

    @log(logger)
    def create_requirements(self, ait_sdk_name: str, base_dir: str) -> None:
        """パッケージ情報のリストをrequirementsファイルに出力する。
        Args:
            ait_sdk_name (str) : ait_sdk名
            base_dir (str) : requirements.txtの保存ディレクトリ

        Returns:
            無し
        """
        base_path = Path(base_dir)

        # requirements.txt作成
        with open(str(base_path/self._req_name), 'w', encoding='utf-8') as f:
            for p_name in self._package_list:
                f.write(p_name + '\n')
            # 最終行に./ait_sdkを追記
            ait_path = './' + ait_sdk_name
            f.write(ait_path)

    @log(logger)
    def move_requirements(self, base_dir: str) -> None:
        """requirementsファイルをdeploy先に移動させる。
        deploy/container/repository以下に移動させる。
        Args:
            base_dir (str) : requirements.txtの保存ディレクトリ

        Returns:
            無し
        """
        base_path = Path(base_dir)

        # requirementsファイルをdeploy先に移動させる。
        shutil.move(str(base_path/self._req_name),
            str(base_path/f'../deploy/container/repository/{self._req_name}'))




