# Copyright © 2019 National Institute of Advanced Industrial Science and Technology （AIST）. All rights reserved.
# !/usr/bin/env python3.6
# coding=utf-8

__version_info__ = (0, 1, 0)
__version__ = '.'.join(map(str, __version_info__))
